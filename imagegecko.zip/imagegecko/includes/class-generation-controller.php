<?php

namespace ImageGecko;

/**
 * Coordinates end-to-end generation requests.
 */
class Generation_Controller {
    const CRON_HOOK  = 'imagegecko_generate_product_image';
    const ASYNC_HOOK = 'imagegecko/generate_product_image';
    const NOTICE_KEY = 'imagegecko_admin_notice';

    /**
     * @var Settings
     */
    private $settings;

    /**
     * @var Mediator_Api_Client
     */
    private $api_client;

    /**
     * @var Image_Handler
     */
    private $image_handler;

    /**
     * @var Logger
     */
    private $logger;

    public function __construct( Settings $settings, Mediator_Api_Client $api_client, Image_Handler $image_handler, Logger $logger ) {
        $this->settings      = $settings;
        $this->api_client    = $api_client;
        $this->image_handler = $image_handler;
        $this->logger        = $logger;
    }

    public function init(): void {
        \add_action( 'admin_notices', [ $this, 'render_admin_notices' ] );

        \add_action( 'wp_ajax_imagegecko_start_generation', [ $this, 'ajax_start_generation' ] );
        \add_action( 'wp_ajax_imagegecko_process_product', [ $this, 'ajax_process_product' ] );
        \add_action( 'wp_ajax_imagegecko_delete_generated_image', [ $this, 'ajax_delete_generated_image' ] );

        \add_action( self::CRON_HOOK, [ $this, 'process_async_job' ], 10, 1 );
        if ( \function_exists( '\as_enqueue_async_action' ) ) {
            \add_action( self::ASYNC_HOOK, [ $this, 'process_async_job' ], 10, 1 );
        }
    }


    public function render_admin_notices(): void {
        $user_id = \get_current_user_id();
        if ( ! $user_id ) {
            return;
        }

        $notice = \get_user_meta( $user_id, self::NOTICE_KEY, true );
        if ( empty( $notice['message'] ) ) {
            return;
        }

        printf(
            '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
            \esc_attr( $notice['type'] ?? 'info' ),
            \esc_html( $notice['message'] )
        );

        \delete_user_meta( $user_id, self::NOTICE_KEY );
    }

    public function queue_generation( int $product_id, array $overrides = [] ): bool {
        if ( $product_id <= 0 ) {
            return false;
        }

        if ( ! $this->should_process_product( $product_id ) ) {
            $this->logger->debug( 'Product skipped by targeting rules.', [ 'product_id' => $product_id ] );
            return false;
        }

        $prompt = $overrides['prompt'] ?? $this->settings->get_default_prompt();
        $prompt = \apply_filters( 'imagegecko_generation_prompt', $prompt, $product_id, $overrides );

        $payload = [
            'product_id' => $product_id,
            'prompt'     => $prompt,
            'categories' => $this->settings->get_selected_categories(),
        ];

        $this->update_status( $product_id, 'queued' );

        if ( \function_exists( '\as_enqueue_async_action' ) ) {
            \as_enqueue_async_action( self::ASYNC_HOOK, [ $payload ], 'imagegecko' );
        } else {
            \wp_schedule_single_event( time(), self::CRON_HOOK, [ $payload ] );
        }

        return true;
    }

    public function generate_product_now( int $product_id, array $overrides = [] ): array {
        if ( $product_id <= 0 ) {
            return [
                'success' => false,
                'status'  => 'failed',
                'message' => \__( 'Invalid product identifier.', 'imagegecko' ),
            ];
        }

        if ( '' === $this->settings->get_api_key() ) {
            return [
                'success' => false,
                'status'  => 'blocked',
                'message' => \__( 'Add your API key before running the workflow.', 'imagegecko' ),
            ];
        }

        if ( ! $this->should_process_product( $product_id ) && empty( $overrides['force'] ) ) {
            $this->logger->debug( 'Product skipped by targeting rules.', [ 'product_id' => $product_id ] );

            return [
                'success' => false,
                'status'  => 'skipped',
                'message' => \__( 'Product skipped by targeting rules.', 'imagegecko' ),
            ];
        }

        $prompt = $overrides['prompt'] ?? $this->settings->get_default_prompt();
        $prompt = \apply_filters( 'imagegecko_generation_prompt', $prompt, $product_id, $overrides );
        $categories = isset( $overrides['categories'] ) ? (array) $overrides['categories'] : $this->settings->get_selected_categories();

        $this->update_status( $product_id, 'queued' );
        $this->update_status( $product_id, 'processing' );

        $result = $this->run_generation( $product_id, $prompt, $categories );

        if ( ! $result['success'] ) {
            $message = $result['error'] ?? \__( 'Generation failed.', 'imagegecko' );
            $this->update_status( $product_id, 'failed', $message );

            return [
                'success' => false,
                'status'  => 'failed',
                'message' => $message,
            ];
        }

        $this->update_status( $product_id, 'completed' );

        return [
            'success'       => true,
            'status'        => 'completed',
            'message'       => \__( 'Product enhanced successfully.', 'imagegecko' ),
            'attachment_id' => $result['attachment_id'] ?? null,
        ];
    }

    public function process_async_job( $payload ): void {
        if ( is_array( $payload ) && isset( $payload[0] ) && is_array( $payload[0] ) && ! isset( $payload['product_id'] ) ) {
            $payload = $payload[0];
        }

        if ( ! is_array( $payload ) || empty( $payload['product_id'] ) ) {
            $this->logger->error( 'Received invalid generation payload.', [ 'payload' => $payload ] );
            return;
        }

        $product_id = (int) $payload['product_id'];
        $prompt     = (string) ( $payload['prompt'] ?? $this->settings->get_default_prompt() );

        $this->update_status( $product_id, 'processing' );
        $categories = isset( $payload['categories'] ) ? (array) $payload['categories'] : $this->settings->get_selected_categories();

        $result = $this->run_generation( $product_id, $prompt, $categories );

        if ( ! $result['success'] ) {
            $message = $result['error'] ?? \__( 'API request failed.', 'imagegecko' );
            $this->update_status( $product_id, 'failed', $message );
            return;
        }

        $this->update_status( $product_id, 'completed' );
    }

    public function ajax_start_generation(): void {
        try {
            $this->verify_ajax_request();

            if ( '' === $this->settings->get_api_key() ) {
                $this->logger->error( 'AJAX start generation failed: No API key configured.' );
                \wp_send_json_error( [ 'message' => \__( 'Add your API key before running the workflow.', 'imagegecko' ) ], 400 );
            }

            $this->logger->info( 'Starting AJAX generation workflow.' );
            
            // Check if anything is selected
            $selected_products   = array_filter( (array) $this->settings->get_selected_products() );
            $selected_categories = array_filter( (array) $this->settings->get_selected_categories() );
            
            if ( empty( $selected_products ) && empty( $selected_categories ) ) {
                $this->logger->info( 'No products or categories selected.' );
                \wp_send_json_error( [ 'message' => \__( 'Please select at least one product or category before running.', 'imagegecko' ) ], 400 );
            }
            
            $product_ids = $this->resolve_target_products();
            $this->logger->info( 'Resolved target products.', [ 'count' => count( $product_ids ), 'product_ids' => $product_ids ] );

            $products = [];
            foreach ( $product_ids as $product_id ) {
                $label = \get_the_title( $product_id );

                if ( \function_exists( '\wc_get_product' ) ) {
                    $product = \wc_get_product( $product_id );
                    if ( $product ) {
                        $label = $product->get_formatted_name();
                    }
                }

                if ( '' === (string) $label ) {
                    /* translators: %d: Product ID */
                    $label = sprintf( \__( 'Product #%d', 'imagegecko' ), $product_id );
                }

                $products[] = [
                    'id'    => $product_id,
                    'label' => $label,
                ];
            }

            $data = [
                'products' => $products,
                'total'    => count( $products ),
            ];

            if ( empty( $products ) ) {
                $data['message'] = \__( 'No published products found in the selected categories.', 'imagegecko' );
                $this->logger->info( 'No products found in selected categories.' );
            }

            $this->logger->info( 'AJAX start generation completed successfully.', [ 'product_count' => count( $products ) ] );
            \wp_send_json_success( $data );
            
        } catch ( \Exception $e ) {
            $this->logger->error( 'AJAX start generation failed with exception.', [ 'error' => $e->getMessage(), 'trace' => $e->getTraceAsString() ] );
            \wp_send_json_error( [ 'message' => \__( 'An error occurred while preparing the generation run. Please check the logs and try again.', 'imagegecko' ) ], 500 );
        }
    }

    public function ajax_process_product(): void {
        try {
            $this->verify_ajax_request();

            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in verify_ajax_request()
            $product_id = isset( $_POST['product_id'] ) ? absint( \wp_unslash( $_POST['product_id'] ) ) : 0;

            if ( $product_id <= 0 ) {
                // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in verify_ajax_request()
                $this->logger->error( 'AJAX process product failed: Invalid product ID.', [ 'provided_id' => isset( $_POST['product_id'] ) ? \sanitize_text_field( \wp_unslash( $_POST['product_id'] ) ) : 'not_set' ] );
                \wp_send_json_error( [ 'message' => \__( 'Invalid product identifier.', 'imagegecko' ) ], 400 );
            }

            $this->logger->info( 'Processing product via AJAX.', [ 'product_id' => $product_id ] );
            
            $result = $this->generate_product_now( $product_id, [ 'force' => true ] );

            $this->logger->info( 'AJAX process product completed.', [ 
                'product_id' => $product_id, 
                'success' => $result['success'], 
                'status' => $result['status'] 
            ] );

            // Get image URLs for display
            $image_data = $this->get_image_data_for_display($product_id, $result['attachment_id'] ?? null);
            
            \wp_send_json_success(
                [
                    'product_id'    => $product_id,
                    'success'       => $result['success'],
                    'status'        => $result['status'],
                    'message'       => $result['message'],
                    'attachment_id' => $result['attachment_id'] ?? null,
                    'images'        => $image_data,
                ]
            );
            
        } catch ( \Exception $e ) {
            $this->logger->error( 'AJAX process product failed with exception.', [ 
                'product_id' => $product_id ?? 0, 
                'error' => $e->getMessage(), 
                'trace' => $e->getTraceAsString() 
            ] );
            \wp_send_json_error( [ 'message' => \__( 'An error occurred while processing the product. Please check the logs and try again.', 'imagegecko' ) ], 500 );
        }
    }


    private function run_generation( int $product_id, string $prompt, array $categories ): array {
        $image_payload = $this->image_handler->prepare_product_image( $product_id );
        if ( \is_wp_error( $image_payload ) ) {
            $message = $image_payload->get_error_message();
            $this->logger->error( 'Failed to prepare source image.', [ 'product_id' => $product_id, 'error' => $message ] );

            return [
                'success' => false,
                'error'   => $message,
            ];
        }

        $product_sku = '';
        if ( \function_exists( '\wc_get_product' ) ) {
            $product     = \wc_get_product( $product_id );
            $product_sku = $product ? (string) $product->get_sku() : '';
        }

        $api_response = $this->api_client->request_generation(
            $product_id,
            $image_payload,
            [
                'prompt'     => $prompt,
                'categories' => $categories,
                'sku'        => $product_sku,
            ]
        );

        if ( ! $api_response['success'] ) {
            $message = $api_response['error'] ?? \__( 'API request failed.', 'imagegecko' );
            $this->logger->error( 'API generation failed.', [ 
                'product_id' => $product_id, 
                'error' => $message,
                'response_code' => $api_response['code'] ?? 'unknown',
                'response_data' => $api_response['data'] ?? null
            ] );

            return [
                'success' => false,
                'error'   => $message,
            ];
        }

        // Log the response structure for debugging
        $this->logger->info( 'API response received.', [ 
            'product_id' => $product_id,
            'response_keys' => array_keys( $api_response['data'] ?? [] ),
            'has_imageBase64' => isset( $api_response['data']['imageBase64'] ),
            'imageBase64_length' => isset( $api_response['data']['imageBase64'] ) ? strlen( $api_response['data']['imageBase64'] ) : 0
        ] );

        // The API returns imageBase64 directly in the response root, not nested under 'data'
        $response_data = $api_response['data'] ?? [];
        
        $media_payload = [
            'image_base64' => $response_data['imageBase64'] ?? null,
            'image_url'    => $response_data['image_url'] ?? null,
            'mime_type'    => $response_data['mime_type'] ?? $response_data['mimeType'] ?? 'image/png',
            'prompt'       => $response_data['prompt'] ?? $prompt,
        ];
        
        // Note: file_name will be generated in persist_generated_media() based on product name
        
        // Validate that we have image data
        if ( empty( $media_payload['image_base64'] ) && empty( $media_payload['image_url'] ) ) {
            $this->logger->error( 'No image data in API response.', [ 
                'product_id' => $product_id,
                'response_keys' => array_keys( $response_data ),
                'media_payload' => $media_payload
            ] );
            
            return [
                'success' => false,
                'error'   => \__( 'API response missing image data. Check API credits and response format.', 'imagegecko' ),
            ];
        }

        $attachment_id = $this->image_handler->persist_generated_media( $product_id, $media_payload );
        if ( \is_wp_error( $attachment_id ) ) {
            $message = $attachment_id->get_error_message();
            $this->logger->error( 'Failed to store generated media.', [ 'product_id' => $product_id, 'error' => $message ] );

            return [
                'success' => false,
                'error'   => $message,
            ];
        }

        $this->logger->info( 'Generated image stored.', [ 'product_id' => $product_id, 'attachment_id' => $attachment_id ] );

        return [
            'success'       => true,
            'attachment_id' => (int) $attachment_id,
        ];
    }

    private function resolve_target_products(): array {
        $selected_products   = array_map( 'intval', (array) $this->settings->get_selected_products() );
        $selected_products   = array_filter( $selected_products );
        $selected_categories = array_map( 'intval', (array) $this->settings->get_selected_categories() );
        $selected_categories = array_filter( $selected_categories );

        // If specific products are selected, use only those (ignore categories)
        if ( ! empty( $selected_products ) ) {
            $this->logger->info( 'Using selected products only.', [ 'count' => count( $selected_products ) ] );
            return array_values( array_unique( $selected_products ) );
        }

        // If categories are selected (but no specific products), get products from those categories
        if ( ! empty( $selected_categories ) ) {
            $category_query = new \WP_Query(
                [
                    'post_type'      => 'product',
                    'fields'         => 'ids',
                    'posts_per_page' => -1,
                    'post_status'    => [ 'publish' ],
                    'no_found_rows'  => true,
                    'tax_query'      => [
                        [
                            'taxonomy' => 'product_cat',
                            'field'    => 'term_id',
                            'terms'    => $selected_categories,
                        ],
                    ],
                ]
            );

            $products = [];
            if ( ! empty( $category_query->posts ) ) {
                $products = array_map( 'intval', $category_query->posts );
            }

            \wp_reset_postdata();
            
            $this->logger->info( 'Using products from selected categories.', [ 'category_count' => count( $selected_categories ), 'product_count' => count( $products ) ] );
            return array_values( array_unique( $products ) );
        }

        // Nothing selected - return empty array (will trigger error in ajax_start_generation)
        $this->logger->info( 'No products or categories selected.' );
        return [];
    }

    private function verify_ajax_request(): void {
        $nonce = isset( $_REQUEST['nonce'] ) ? \sanitize_text_field( \wp_unslash( $_REQUEST['nonce'] ) ) : '';
        
        $this->logger->debug( 'Verifying AJAX request.', [ 
            'nonce_provided' => !empty( $nonce ),
            'user_id' => \get_current_user_id(),
            'can_manage_woocommerce' => \current_user_can( 'manage_woocommerce' )
        ] );

        if ( ! \wp_verify_nonce( $nonce, Admin_Settings_Page::NONCE_ACTION ) ) {
            $this->logger->error( 'AJAX request failed nonce verification.', [ 'provided_nonce' => $nonce ] );
            \wp_send_json_error( [ 'message' => \__( 'Invalid request nonce.', 'imagegecko' ) ], 403 );
        }

        if ( ! \current_user_can( 'manage_woocommerce' ) ) {
            $this->logger->error( 'AJAX request failed permission check.', [ 'user_id' => \get_current_user_id() ] );
            \wp_send_json_error( [ 'message' => \__( 'You do not have permission to perform this action.', 'imagegecko' ) ], 403 );
        }
        
        $this->logger->debug( 'AJAX request verification passed.' );
    }

    private function should_process_product( int $product_id ): bool {
        $selected_products = $this->settings->get_selected_products();
        if ( ! empty( $selected_products ) && ! in_array( $product_id, $selected_products, true ) ) {
            return false;
        }

        $selected_categories = $this->settings->get_selected_categories();
        if ( empty( $selected_categories ) ) {
            return true;
        }

        $product_cats = \wp_get_post_terms( $product_id, 'product_cat', [ 'fields' => 'ids' ] );

        return ! empty( array_intersect( $selected_categories, $product_cats ) );
    }

    private function update_status( int $product_id, string $status, string $message = '' ): void {
        \update_post_meta( $product_id, '_imagegecko_status', $status );
        \update_post_meta( $product_id, '_imagegecko_status_message', $message );
        if ( 'failed' === $status ) {
            /* translators: 1: Product ID, 2: Error message */
            $this->enqueue_notice( 'error', sprintf( \__( 'ImageGecko failed for product #%1$d: %2$s', 'imagegecko' ), $product_id, $message ) );
        }
    }

    private function enqueue_notice( string $type, string $message ): void {
        $user_id = \get_current_user_id();
        if ( ! $user_id ) {
            return;
        }

        \update_user_meta(
            $user_id,
            self::NOTICE_KEY,
            [
                'type'    => $type,
                'message' => $message,
            ]
        );
    }
    
    public function ajax_delete_generated_image(): void {
        try {
            $this->verify_ajax_request();

            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in verify_ajax_request()
            $attachment_id = isset( $_POST['attachment_id'] ) ? absint( \wp_unslash( $_POST['attachment_id'] ) ) : 0;

            if ( $attachment_id <= 0 ) {
                // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in verify_ajax_request()
                $this->logger->error( 'AJAX delete generated image failed: Invalid attachment ID.', [ 'provided_id' => isset( $_POST['attachment_id'] ) ? \sanitize_text_field( \wp_unslash( $_POST['attachment_id'] ) ) : 'not_set' ] );
                \wp_send_json_error( [ 'message' => \__( 'Invalid attachment identifier.', 'imagegecko' ) ], 400 );
            }

            // Verify this is actually a generated image
            $is_generated = \get_post_meta( $attachment_id, '_imagegecko_generated', true );
            if ( ! $is_generated ) {
                $this->logger->error( 'AJAX delete generated image failed: Not a generated image.', [ 'attachment_id' => $attachment_id ] );
                \wp_send_json_error( [ 'message' => \__( 'This is not a generated image.', 'imagegecko' ) ], 400 );
            }

            $this->logger->info( 'Deleting generated image via AJAX.', [ 'attachment_id' => $attachment_id ] );
            
            // Get the product ID before deleting the attachment
            $product_id = (int) \get_post_meta( $attachment_id, '_imagegecko_product_id', true );
            
            // Check if this is the current featured image
            $is_featured_image = false;
            if ( $product_id ) {
                $current_featured_id = (int) \get_post_thumbnail_id( $product_id );
                $is_featured_image = ( $current_featured_id === $attachment_id );
            }
            
            // Delete the attachment
            $deleted = \wp_delete_attachment( $attachment_id, true );
            
            if ( ! $deleted ) {
                $this->logger->error( 'Failed to delete generated image.', [ 'attachment_id' => $attachment_id ] );
                \wp_send_json_error( [ 'message' => \__( 'Failed to delete the image.', 'imagegecko' ) ], 500 );
            }

            $this->logger->info( 'Generated image deleted successfully.', [ 'attachment_id' => $attachment_id ] );
            
            // If the deleted image was the featured image, restore the original
            if ( $is_featured_image && $product_id ) {
                $this->image_handler->restore_original_featured_image( $product_id );
            }
            
            // Clean up all product meta related to this attachment
            if ( $product_id ) {
                // Remove all instances of this attachment ID from the generated attachment meta
                // get_post_meta with false returns all values, but we need to delete each instance
                $meta_ids = $GLOBALS['wpdb']->get_col( $GLOBALS['wpdb']->prepare(
                    "SELECT meta_id FROM {$GLOBALS['wpdb']->postmeta} WHERE post_id = %d AND meta_key = %s AND meta_value = %s",
                    $product_id,
                    '_imagegecko_generated_attachment',
                    (string) $attachment_id
                ) );
                
                foreach ( $meta_ids as $meta_id ) {
                    \delete_metadata_by_mid( 'post', $meta_id );
                }
                
                // Also delete the single meta value if it matches (in case delete_metadata_by_mid didn't catch it)
                $current_generated = (int) \get_post_meta( $product_id, '_imagegecko_generated_attachment', true );
                if ( $current_generated === $attachment_id ) {
                    \delete_post_meta( $product_id, '_imagegecko_generated_attachment' );
                    \delete_post_meta( $product_id, '_imagegecko_generated_at' );
                }
                
                // Clear status metadata to allow re-generation
                \delete_post_meta( $product_id, '_imagegecko_status' );
                \delete_post_meta( $product_id, '_imagegecko_status_message' );
                
                // Also check if this attachment exists in the gallery and remove it
                $gallery = \get_post_meta( $product_id, '_product_image_gallery', true );
                if ( ! empty( $gallery ) ) {
                    $gallery_ids = array_map( 'intval', explode( ',', $gallery ) );
                    $gallery_ids = array_filter( $gallery_ids, function( $id ) use ( $attachment_id ) {
                        return $id !== $attachment_id;
                    } );
                    if ( empty( $gallery_ids ) ) {
                        \delete_post_meta( $product_id, '_product_image_gallery' );
                    } else {
                        \update_post_meta( $product_id, '_product_image_gallery', implode( ',', $gallery_ids ) );
                    }
                }
            }

            \wp_send_json_success( [
                'message' => \__( 'Image deleted successfully.', 'imagegecko' ),
                'attachment_id' => $attachment_id,
                'featured_restored' => $is_featured_image,
            ] );
            
        } catch ( \Exception $e ) {
            $this->logger->error( 'AJAX delete generated image failed with exception.', [ 
                'attachment_id' => $attachment_id ?? 0, 
                'error' => $e->getMessage(), 
                'trace' => $e->getTraceAsString() 
            ] );
            \wp_send_json_error( [ 'message' => \__( 'An error occurred while deleting the image. Please try again.', 'imagegecko' ) ], 500 );
        }
    }
    
    /**
     * Get image data for display in the progress tracker.
     */
    private function get_image_data_for_display(int $product_id, ?int $generated_attachment_id): array {
        $image_data = [
            'source' => null,
            'generated' => null,
        ];
        
        // Get source image (the original image that was used for generation)
        $source_image_data = $this->image_handler->prepare_product_image($product_id);
        if (!\is_wp_error($source_image_data) && isset($source_image_data['attachment_id'])) {
            $source_attachment_id = $source_image_data['attachment_id'];
            $source_url = \wp_get_attachment_image_url($source_attachment_id, 'large');
            $source_full_url = \wp_get_attachment_image_url($source_attachment_id, 'full');
            if ($source_url) {
                $image_data['source'] = [
                    'url' => $source_url,
                    'full_url' => $source_full_url ?: $source_url,
                    'attachment_id' => $source_attachment_id,
                    'title' => \get_the_title($source_attachment_id) ?: 'Source Image',
                ];
            }
        }
        
        // Get generated image if available
        if ($generated_attachment_id) {
            $generated_url = \wp_get_attachment_image_url($generated_attachment_id, 'large');
            $generated_full_url = \wp_get_attachment_image_url($generated_attachment_id, 'full');
            if ($generated_url) {
                $image_data['generated'] = [
                    'url' => $generated_url,
                    'full_url' => $generated_full_url ?: $generated_url,
                    'attachment_id' => $generated_attachment_id,
                    'title' => \get_the_title($generated_attachment_id) ?: 'Generated Image',
                ];
            }
        }
        
        return $image_data;
    }
}
